#box
class box:
    print("Calculate a Box:")
    length = int(input("Enter Length: "))
    width = int(input("Enter Width: "))
    height = int(input("Enter Height: "))
    def __init__(self, length, width, height):
        self.length = length
        self.width = width
        self.height = height
        
