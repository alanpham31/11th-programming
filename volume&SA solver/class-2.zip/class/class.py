print("Welcome to Geometry calculator!")
import box
def volumeB():
    print("Volume of Box: ", box.length*box.width*box.height)
volumeB()
def SAB():
    print("Surface Area of Box: ", box.length*box.width*4+2*box.height)
SAB()

import sphere
def volumeS():
    print("Assumption: pi = 3.1415")
    print("Volume of Sphere: ", (4/3)*3.1415*sphere.radius*sphere.radius*sphere.radius)
volumeS()
def SAS():
    print("Assumption: pi = 3.1415")
    print("Surface Area of Sphere: ", 4*3.1415*sphere.radius*sphere.radius)
SAS()

import pyramid
def volumeP():
    print("Volume of Pyramid: ", (pyramid.length*pyramid.width*pyramid.height)/3)
volumeP()
def SAP():
    print("Surface Area of Pyramid: ", pyramid.length*pyramid.width+(pyramid.length((pyramid.width/2)**2)+pyramid.height**2+pyramid.width)**(1/2)+((pyramid.width(pyramid.length/2)**2)+h**2)**(1/2))
SAP()
