#sphere
class sphere:
    print("Calculate a Sphere:")
    radius = int(input("Enter Radius: "))
    def __init__(self, radius):
        self.radius = radius
