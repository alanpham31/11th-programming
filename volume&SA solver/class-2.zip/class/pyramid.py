#pyramid
class pyramid():
    print("Calculate a Pyramid:")
    width = int(input("Enter Width: "))
    length = int(input("Enter Length: "))
    height = int(input("Enter Height: "))
    def __init__(self, width, length, height):
        self.width = width
        self.length = length
        self.height = height
